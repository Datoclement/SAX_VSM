import numpy as np
import scipy.special as sc
import multiprocessing as mp

import formats as fm
import helper  as hp
import sparse_matrix as sm
import gradient_descent as gd

from sklearn.base import BaseEstimator
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA,NMF
from sklearn.model_selection import StratifiedShuffleSplit


import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib import cm
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap,BoundaryNorm


import python.performance_critical_functions as pcf

import time

outputpath = '../output/'

t1 = 0.0
t2 = 0.0
t3 = 0.0

eps = 1E-6

class saxvsm(BaseEstimator) :

    num_class    = None
    len_window   = None
    len_word     = None
    num_alphabet = None
    num_vars     = None
    reduction    = None
    weighting    = None
    mean         = None
    trend        = None

    @classmethod
    def tostring(cls):
        return str(cls.len_window) + '\t' \
                + str(cls.len_word) + '\t' \
                + str(cls.num_alphabet) + '\t' \
                + str(cls.reduction) + '\t' \
                + cls.weighting + '\t' \
                + str(cls.mean) + '\t' \
                + str(cls.trend) + '\t' \
                + cls.inter_var

    @classmethod
    def init(cls,params,dtshape,config) :
        """
        initialize
        parameters (length of window, length of PAA, size of alphabet),
        dtshape    (number of classes, _, number of variants),
        config     (weighting, numerosity reduction, offset(mean), slope(trend), multivariate mode)
        """
        cls.num_class ,  _            ,  cls.num_vars                = dtshape
        cls.len_window,  cls.len_word ,  cls.num_alphabet            = params
        cls.weighting ,  cls.reduction,  cls.mean,        cls.trend  = config['conf']

        cls.inter_var                                                = config['inter_var']
        cls.sgd       ,  cls.sgd_params                              = config['sgd'],config['sgd_params']

        cls.save_instance = cls.sgd

    def __init__(self,len_window=None,len_word=None,num_alphabet=None) :
        """
        constructor
        initialize the tfidf weight matrix, and the counters of instances for each class
        initialize counters of word (tfidf matrix grows dynamically in O(1) amortised time complexity)
        """
        if not saxvsm.num_class :
            raise Exception('saxvsm non initialized.')

        self.len_window     = saxvsm.len_window     if len_window    is None else len_window
        self.len_word       = saxvsm.len_word       if len_word      is None else len_word
        self.num_alphabet   = saxvsm.num_alphabet   if num_alphabet  is None else num_alphabet

        self.num_class      = saxvsm.num_class
        self.num_vars       = saxvsm.num_vars
        self.reduction      = saxvsm.reduction
        self.weighting      = saxvsm.weighting
        self.mean           = saxvsm.mean
        self.trend          = saxvsm.trend
        self.inter_var      = saxvsm.inter_var
        self.sgd            = saxvsm.sgd
        self.sgd_params     = saxvsm.sgd_params
        self.save_instance  = saxvsm.save_instance


        self.total_instance = 0
        self.cap_word       = 1
        self.num_word       = 0

        self.num_instance_class = np.zeros(shape=(1,self.num_class),dtype=int)

        self.X_matrix = sm.sparse_matrix()
        self.y_matrix = sm.sparse_matrix(row=self.num_class)

        self.tf = np.zeros(shape=(self.cap_word,self.num_class))
        self.df = np.zeros(shape=(self.cap_word,1))
        self.cf = np.zeros(shape=(self.cap_word,self.num_class))
        self.ff = np.zeros(shape=(self.cap_word,1))

        self.word_dict = dict()

        self.__state = 'train'

    def __sequence_of_words(self,instance,len_window=None,len_word=None,num_alphabet=None):
        """
        Transform instance into a sequence of SAX word (ordred)
        """

        global t1,t2,t3

        if len_window is None:
            len_window   = self.len_window
            len_word     = self.len_word
            num_alphabet = self.num_alphabet

        num_word     = self.num_word
        cap_word     = self.cap_word
        num_vars     = self.num_vars
        len_series   = len(instance)//num_vars

        sequence = []

        def find_indices_of_words(words):
            global t1,t2,t3
            # t1 -= time.time()
            if self.inter_var == 'conjoint':
                words = [ words ]
            elif self.inter_var == 'independ':
                words = [ w for w in words ]
            elif self.inter_var == 'mixed':
                words = [ words ] + [ w for w in words ]
            # t1 += time.time()
            result = []
            for w in words:
                # t2 -= time.time()
                word      = w.tostring()
                word_dict = self.word_dict
                num_class = self.num_class

                # t2 += time.time()
                # t3 -= time.time()

                if not word in word_dict:

                    if self.__state == 'train' :
                        word_dict[word] = self.num_word
                        if self.num_word == self.cap_word :
                            self.cap_word *= 2
                        result += [self.num_word]
                        self.num_word += 1
                    else :
                        result += [-1]

                else:
                    result += [word_dict[word]]

                # t3 += time.time()

            return result

        # t1 -= time.time()

        instance   = np.concatenate((instance,np.zeros(shape=(num_vars))),axis=0)
        pinstance  = np.concatenate((np.repeat(np.arange(len_series),num_vars),np.zeros(shape=(num_vars))),axis=0) * instance

        ttmean     = np.array([np.mean(instance[i::num_vars]) for i in range(num_vars)])
        ttstd      = np.array([np.var(instance[i::num_vars]) for i in range(num_vars)]) ** 0.5

        curmean    = np.array([np.mean(instance[i:num_vars*len_window:num_vars]) for i in range(num_vars)])
        curvar     = np.array([np.var(instance[i:num_vars*len_window:num_vars]) for i in range(num_vars)])

        pos        = np.array([i*len_window//len_word for i in range(len_word+1)],dtype=int) * num_vars
        cut        = np.array([i*len_window%len_word for i in range(len_word+1)],dtype=int)

        pos_tail   = pos[1:]
        pos_head   = pos[:-1]
        cut_tail   = cut[1:]
        cut_head   = cut[:-1]

        idi        = np.expand_dims(np.arange(len_word,dtype=int),axis=1)
        idj        = np.expand_dims(np.arange(len_window,dtype=int),axis=0)
        idv        = np.expand_dims(np.expand_dims(np.arange(num_vars,dtype=int),axis=1),axis=2)
        indices    = (idi * len_window + idj) // len_word
        pos_ist    = idv + np.expand_dims(indices*num_vars,axis=0)

        curmeans      = np.mean(instance[pos_ist],axis=2)
        curcrossps    = np.mean(pinstance[pos_ist],axis=2)

        # t1 += time.time()
        # t2 -= time.time()

        xvars         = np.var(indices,axis=1)
        xmeans        = np.mean(indices,axis=1)

        curmean_cn    = np.array([(curmean[i] - ttmean[i]) if ttstd[i] <= 0.0 else ((curmean[i] - ttmean[i])/ttstd[i]) \
                                for i in range(num_vars)])
        curmeans_cn   = np.array([(curmeans[i]-curmean[i]) if curvar[i] <= 0.0 else ((curmeans[i]-curmean[i])/(curvar[i]**0.5)) \
                                for i in range(num_vars)])
        curcrossps_cn = curcrossps - xmeans * curmeans

        word_mat      = pcf.word_matrix_generator(instance,pinstance,
                                                  curmean,curvar,pos,cut,curmeans,curcrossps,xmeans,\
                                                  curmean_cn,curmeans_cn,curcrossps_cn,\
                                                  ttmean,ttstd,len_series,len_window,len_word,num_vars,num_alphabet,\
                                                  self.trend,self.mean)

        l        = len_window
        lastword = [None]

        if num_vars > 1:
            if self.inter_var == 'conjoint':
                lastword = [None]
            if self.inter_var == 'independ':
                lastword = [None] * num_vars
            if self.inter_var == 'mixed':
                lastword = [None] * (num_vars+1)

        # t2 += time.time()
        # t3 -= time.time()

        for p in range(len_series-len_window+1) :

            # t1 -= time.time()

            words    = word_mat.next()

            # t1 += time.time()
            # t2 -= time.time()

            curwords = find_indices_of_words(words)

            # t2 += time.time()
            # t3 -= time.time()

            if not self.reduction:
                sequence += curwords
            else:
                to_add = []
                for i in range(len(curwords)):
                    if curwords[i] == -1 or lastword[i] == curwords[i]:
                        to_add += [-1]
                    else:
                        to_add += [curwords[i]]
                        lastword[i] = curwords[i]
                sequence += to_add

            # t3 += time.time()

        # t3 += time.time()

        return sequence

    def __sax(self,instance):
        """
        Transfer a time series into a SAX word frequency vector
        """
        global t1,t2,t3

        # t1 -= time.time()

        sow = None

        if isinstance(self.len_window,list):
            sow = []
            for i in range(len(self.len_window)):
                sow += self.__sequence_of_words(instance,\
                                                len_window   = self.len_window[i],\
                                                len_word     = self.len_word[i],\
                                                num_alphabet = self.num_alphabet[i])
        else:
            sow = self.__sequence_of_words(instance)

        # t1 += time.time()
        # t2 -= time.time()
        sow = np.asarray(sow)
        words_vect = np.zeros(shape=(self.cap_word),dtype=int)

        lastword = None

        for word in sow:
            if word == -1:
                continue
            words_vect[word] += 1

        # t2 += time.time()

        return words_vect

    def __update(self,resume,num_added):
        """
        update the tfidf matrix
        """

        dim_to_expand = max(self.num_word - self.df.shape[0],0)

        self.df = np.concatenate((self.df,np.zeros(shape=(dim_to_expand,self.df.shape[1]))),axis=0)
        self.tf = np.concatenate((self.tf,np.zeros(shape=(dim_to_expand,self.tf.shape[1]))),axis=0)
        self.cf = np.concatenate((self.cf,np.zeros(shape=(dim_to_expand,self.cf.shape[1]))),axis=0)
        self.ff = np.concatenate((self.ff,np.zeros(shape=(dim_to_expand,self.ff.shape[1]))),axis=0)

        self.num_instance_class += num_added
        self.total_instance     += np.sum(num_added)

        try:
            self.cf += (resume>0.0) * num_added                                  # presence in class
            self.tf += resume                                                    # number occurrence in class
            self.df += np.sum((resume>0.0) * num_added,axis=1,keepdims=True)     # presence in total
            self.ff += np.sum(resume,axis=1,keepdims=True)                       # number occurrence in total
        except(ValueError):
            news = str(self.cf.shape) + '\t' \
                 + str(self.tf.shape) + '\t' \
                 + str(self.df.shape) + '\t' \
                 + str(self.ff.shape) + '\t' \
                 + str(resume.shape)
            fm.cursor_print(news,y=-1)
            exit()

    def __set_state(self,state):
        if self.__state == state:
            return
        self.__state = state
        if state == 'predict':

            w  = self.num_word
            nc = (self.num_instance_class > 0) * self.num_instance_class - (self.num_instance_class <=0)

            tf = self.tf[:w]
            df = self.df[:w]
            cf = self.cf[:w]
            ff = self.ff[:w]

            if self.weighting == 'tfidf':
                self.weights = - np.log(1.0+tf/(1.0*nc)) \
                    * np.log(df/(1.0*self.total_instance))

            if self.weighting == 'ntfidf':
                self.weights = hp.normalize(- np.log(1.0+tf/(1.0*nc)) \
                    * np.log(df/(1.0*self.total_instance)), axis=0)

            if self.weighting == 'arctan':
                self.weights = np.tan((np.arctan((tf / (1.0 * nc) + eps) \
                        / ((ff-tf) / (1.0 * (self.total_instance - nc)) + eps)) \
                        - np.arctan(1.0)) * 2)

            if self.weighting == 'warctan':
                self.weights = np.tan((np.arctan((tf / (1.0 * nc) + eps) \
                        / ((ff-tf) / (1.0 * (self.total_instance - nc)) + eps)) \
                        - np.arctan(1.0)) * 2) * (np.amax(tf / (1.0*ff),axis=1,keepdims=True) - (1/(1.0*self.num_class)))

            if self.weighting == 'dwarc':
                self.weights = np.tan((np.arctan((tf / (1.0 * nc) + eps) \
                        / ((ff-tf) / (1.0 * (self.total_instance - nc)) + eps)) \
                        - np.arctan(1.0)) * 2) * (np.amax(tf / (1.0*ff),axis=1,keepdims=True) - (1/(1.0*self.num_class))) \
                        * ((cf / (1.0*nc)) ** 2)

            if self.weighting == 'narctan':
                self.weights = hp.normalize(np.tan((np.arctan((tf / (1.0 * nc) + eps) \
                        / ((ff-tf) / (1.0 * (self.total_instance - nc)) + eps)) \
                        - np.arctan(1.0)) * 2), axis=0)

    def __gradient_calculator(self):
        """
        Depreciated
        """

        closure_param = dict()
        closure_param['X'] = self.X_matrix.to_matrix().T.astype(float)
        closure_param['y'] = self.y_matrix.to_matrix().T.astype(float)
        closure_param['W'] = self.weights
        closure_param['l'] = self.sgd_params['regularization']

        def gradient(ids):


            X = closure_param['X'][ids]
            y = closure_param['y'][ids]
            W = closure_param['W']
            l = closure_param['l']

            result = 2 * l * W

            Y       = np.dot(X,W)
            sigma_Y = hp.sigmoid(Y)
            err_y   = sigma_Y - y

            #errs_y  = np.sum(err_y, axis=1, keepdims=True)
            #news = 'Y:\n' + str(Y) + '\nmask:\n' + str(mask)
            #fm.cursor_print(news,y=2)

            X       = np.expand_dims(X     , axis=2)
            err_y   = np.expand_dims(err_y , axis=1)
            #errs_y  = np.expand_dims(errs_y , axis=1)

            for i in range(len(ids)):
                result += err_y[i] * X[i]

            news = str((2*l*W)[:10]) + '\n' + str((result)[:10])  + '\n' + str(self.weights[:10])
            #fm.cursor_print(news,y=2)

            return result

        return gradient

    def __check_label(self,y):
        """
        To ensure the input labels are in binary format.
        """
        if len(y.shape) == 1:
            return hp.binarize(y,classes=range(self.num_class))
        else:
            return y

    def fit(self,X,y,weights = [-1],test = None,return_dict = None,index=None) :
        """
        Train function
        """

        y           = self.__check_label(y)

        instances   = X
        labels      = y
        num_inst    = len(X)

        global t1,t2,t3

        t1 -= time.time()

        self.__set_state('train')


        resume = np.zeros(shape=(self.cap_word,self.num_class))
        num_instance_added = np.expand_dims(np.zeros(shape=(self.num_class),dtype=int),axis=0)

        old_num = self.cap_word

        if weights[0] < 0:
            weights = np.zeros(shape=(len(instances)))+1.0

        for i in range(len(instances)):
            # print '%d,%d' % (self.cap_word,self.num_word)
            # t1 -= time.time()
            words = self.__sax(instances[i])
            # t1 += time.time()
            # t2 -= time.time()
            label = np.argmax(labels[i])
            num_instance_added[0,label] += 1
            if old_num != self.cap_word :
                resume = np.concatenate((resume,\
                        np.zeros(shape=(self.cap_word-old_num,self.num_class))),axis=0)
                old_num = self.cap_word
            resume[:,label] += words * weights[i]

            if self.save_instance:
                self.X_matrix.add_col(words)
                self.y_matrix.add_col(labels[i])

            # t2 += time.time()

        self.__update(resume[:self.num_word],num_instance_added)

        if self.sgd:

            self.__set_state('predict')


            gd.gradient_descent(weights   = self.weights,\
                                gradient  = self.__gradient_calculator(),\
                                instances = instances,\
                                labels    = labels,\
                                score     = self.score,\
                                conf      = self.sgd_params,\
                                test      = test,\
                                index     = index)

        else:
            pass
            #
            # news = 'no sgd' + ' test_score ' + fm.float_form % self.score(test['X'],test['y'])
            # fm.cursor_print(news,y=int(mp.current_process().name)+20)

        t1 += time.time()
        return self

    def similarity_matrix(self,instances):
        """
        Calculate similarity between each instance and each class
        """
        self.__set_state('predict')
        matrix = np.array([self.__sax(i) for i in instances])[:,:self.num_word]
        return np.array([[ np.dot(matrix[i,:],self.weights[:,c])  for c in range(self.num_class) ] for i in range(len(instances)) ])

    def predict_proba(self,instances):
        """
        Probability calibration
        """
        return hp.softmax(self.similarity_matrix(instances),axis=1)

    def predict(self,instances) :
        """
        1-hot prediction
        """

        global t1,t2,t3
        # t3 -= time.time()
        res = hp.binarize(np.argmax(self.similarity_matrix(instances),axis=1), \
                classes=range(self.num_class))
        # t3 += time.time()
        # print 't1:',
        # print t1,
        # print ' t2:',
        # print t2,
        # print ' t3:',
        # print t3
        return res


    def interpret(self,instance,title='test.png',truth=-1) :
        """
        Give an interpretation image from trained model for the instance.
        """
        self.__set_state('predict')

        num_vars = self.num_vars
        len_series = len(instance) / num_vars

        sow = np.array(self.__sequence_of_words(instance))
        ist_class = np.argmax(self.predict(np.array([instance])))

        fig = plt.figure()

        def interpret_in_class(c,plot):

            soc = np.zeros(shape=sow.shape)
            for i in range(len(sow)):
                if sow[i] < 0:
                    continue
                soc[i] = self.weights[sow[i],c]

            if self.inter_var == 'conjoint' :
                carr = np.array([[np.sum( \
                        soc[max(0,i-self.len_window+1):i+1]) \
                        for i in range(len_series)] \
                        for v in range(num_vars)])
            if self.inter_var == 'independ' :
                carr = np.array([[np.sum( \
                        soc[max(0,i-self.len_window+1)*num_vars+v:(i+1)*num_vars+v:num_vars]) \
                        for i in range(len_series)] \
                        for v in range(num_vars)])
            if self.inter_var == 'mixed' :
                carr = np.array([[np.sum( \
                        soc[max(0,i-self.len_window+1)*(num_vars+1)+v+1:(i+1)*(num_vars+1)+v+1:(num_vars+1)]) \
                        for i in range(len_series)] \
                        for v in range(num_vars)]) \
                        + np.array([[np.sum( \
                        soc[max(0,i-self.len_window+1)*(num_vars+1):(i+1)*(num_vars+1):(num_vars+1)]) \
                        for i in range(len_series)] \
                        for v in range(num_vars)])

            carr = hp.softmax(carr,alpha=3.0,axis=-1)
            # print(carr)
            carr -= np.min(carr)
            mx = np.max(carr)
            if mx != 0.0:
                carr /= mx
            carr = carr / 2.0

            # carr = (np.arctan(carr) + np.pi / 2.0) / np.pi / 2.0
            # for c in carr[0]:
            #     print(c)

            x = np.arange(len_series)
            points = np.array([np.array([x,instance[v::num_vars]]).T.reshape(-1,1,2) \
                    for v in range(num_vars)])
            segments = np.array([np.concatenate([points[v,:-1], points[v,1:]], axis=1) \
                    for v in range(num_vars)])

            lc = [LineCollection(segments[v], \
                    cmap=ListedColormap([cm.brg(c) for c in carr[v]]), \
                    norm=BoundaryNorm([i-0.5 for i in range(len_series+1)],len_series)) \
                    for v in range(num_vars)]
            for l in lc:
                l.set_array(x)
                l.set_linewidth(3)

            subplots = gridspec.GridSpecFromSubplotSpec(num_vars,1,subplot_spec=plot)#,sharex=True)
            pvax = None

            for v in range(num_vars):
                if not pvax:
                    ax = plt.Subplot(fig,subplots[v])
                    pvax = ax
                    ax.set_xlim(x.min(), x.max())
                else:
                    ax = plt.Subplot(fig,subplots[v],sharex=pvax)
                ax.add_collection(lc[v])
                ax.set_ylim(instance[v::num_vars].min(), instance[v::num_vars].max())
                ax.grid(True)
                fig.add_subplot(ax)

            plt.sca(pvax)
            # plt.xlim(x.min(), x.max())

            # plt.gca().add_collection(lc)
            # plt.xlabel('time')
            # plt.ylabel('amplitude')
            # plt.ylim(instance.min(), instance.max())
            # plt.grid(True)

        if truth < 0 or ist_class == truth :

            outer = gridspec.GridSpec(1, 1)
            plt.title('Class '+str(ist_class))
            interpret_in_class(ist_class,outer[0])

        else :

            outer = gridspec.GridSpec(2, 1)

            # plt.subplot(211)
            interpret_in_class(ist_class,plot=outer[0])
            plt.title('Prediction: '+str(ist_class))

            # plt.subplot(212)
            interpret_in_class(truth,plot=outer[1])
            plt.title('Truth: '+str(truth))

            plt.tight_layout()

        plt.savefig(outputpath + title)
        plt.close()


    def score(self,X,y):
        """
        Test function, return the accuracy score
        """
        y = self.__check_label(y)
        return accuracy_score(self.predict(X),y)
