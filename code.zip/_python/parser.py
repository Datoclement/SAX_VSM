import numpy   as np
import pandas  as pd

import formats as fm
import helper  as hp

from sklearn.model_selection import StratifiedShuffleSplit

def parse(filename, folder) :

    if folder == 'uts_dataset':

        return parse_uts(filename)

    else:
        return parse_mts(filename)

def parse_uts(filename):

    relative_path = '../data/uts_dataset/'

    train = dict()
    test  = dict()

    # get raw
    train_path = relative_path+filename+"/"+filename+'_TRAIN'
    train_df   = pd.read_csv(train_path, sep=',', header=None, engine='python')
    train_raw  = train_df.as_matrix()

    # get X
    train['X'] = train_raw[:,1:]

    # get y
    train['y'] = train_raw[:,0]
    classes = np.unique(train['y'])
    train['y'] = hp.binarize(train['y'],classes=classes)

    # get meta information
    num_vars = 1
    num_class = len(classes)
    len_series = min([len(train['X'][i]) for i in range(len(train['X']))]) / num_vars
    train['shape'] = np.array([num_class,len_series,num_vars],dtype=int)

    # get raw
    test_path = relative_path+filename+"/"+filename+"_TEST"
    test_df = pd.read_csv(test_path, sep=',', header=None, engine='python')
    test_raw = test_df.as_matrix()

    # get X
    test['X'] = test_raw[:,1:]

    # get y
    test['y'] = test_raw[:,0]
    test['y'] = hp.binarize(test['y'],classes=classes)

    return train,test,len(train['y']),len(test['y']),filename

def parse_mts(filename) :

    relative_path = '../data/mts_dataset/'

    train = dict()
    test  = dict()

    # get raw
    train_path = relative_path+filename+"/"+filename+'_TRAIN'
    train_df   = pd.read_csv(train_path, sep='\s', header=None, engine='python')
    train_raw  = train_df.as_matrix()

    # get X
    rank_ser   = train_raw[:,0]
    tr_X_raw   = train_raw[:,3:]
    serie_bg   = np.array([0] \
                        + [ i for i in range(len(rank_ser)) if i > 0 and rank_ser[i] != rank_ser[i-1]] \
                        + [len(rank_ser)])
    train['X'] = np.array([ np.concatenate(tr_X_raw[serie_bg[i]:serie_bg[i+1]],axis=0) for i in range(len(serie_bg)-1) ])

    # get y
    train['y'] = train_raw[serie_bg[:-1],2]
    classes = np.unique(train['y'])
    train['y'] = hp.binarize(train['y'],classes=classes)

    # get meta information
    num_vars   = len(train_raw[0]) - 3
    num_class = len(classes)
    len_series = min([len(train['X'][i]) for i in range(len(train['X']))]) / num_vars
    train['shape'] = np.array([num_class,len_series,num_vars],dtype=int)

    # get raw
    test_path = relative_path+filename+"/"+filename+"_TEST"
    test_df = pd.read_csv(test_path, sep='\s', header=None, engine='python')
    test_raw = test_df.as_matrix()

     # get X
    rank_ser   = test_raw[:,0]
    tr_X_raw   = test_raw[:,3:]
    serie_bg   = np.array([0] + [ i for i in range(len(rank_ser)) if i > 0 and rank_ser[i] != rank_ser[i-1]] + [len(rank_ser)])
    test['X'] = np.array([ np.concatenate(tr_X_raw[serie_bg[i]:serie_bg[i+1]],axis=0) for i in range(len(serie_bg)-1) ])

    # get y
    test['y'] = test_raw[serie_bg[:-1],2]
    test['y'] = hp.binarize(test['y'],classes=classes)

    return train,test,len(train['y']),len(test['y']),filename
