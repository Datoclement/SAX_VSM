import numpy           as np
import multiprocessing as mp

import saxvsm    as sv
import optimizer as opt
import formats   as fm
import helper    as hp

from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics         import accuracy_score


class ensemble:

    num_sax = None
    saxvsms = None
    weights = None
    paramss = None
    dtshape = None
    config = None
    num_class = None

    def __init__(self,dataset,config):

        self.num_sax, self.samples, self.softmax_power, self.num_filter = config['esb_conf']
        
        self.saxvsms = list()
        self.paramss = []
        self.weights = []

        def fibo():
            a = 1
            b = 1
            for i in range(self.num_sax):
                t = b
                b = a+b
                a = t
                yield b

        data = dataset[0]
        self.dtshape = data['shape']
        self.config = config

        self.num_class,len_series,_ = data['shape']

        low = [1,1,1]
        upp = [len_series,30,20]
        
        paramss = []
        for i in range(3):
            paramss += [np.random.randint(low=low[i],high=upp[i],size=(self.num_sax,self.num_filter))]
            
        for i in range(self.num_sax):
            params = [paramss[0][i].tolist(),paramss[1][i].tolist(),paramss[2][i].tolist()]
            sv.saxvsm.init(params,data['shape'],config)
            self.saxvsms += [sv.saxvsm()]
            self.paramss += [params]

    def fit(self,instances,labels,test=None):

        # bagging
        partitions = StratifiedShuffleSplit(n_splits=len(self.saxvsms),\
                                            test_size=self.samples,\
                                            random_state=1).split(X=instances,y=labels)

        for i,t in enumerate(partitions):
            print (self.paramss[i])
            news = 'training ' + fm.int_form % i + ' ' + fm.param_to_string(self.paramss[i])
            fm.cursor_print(news,y=i+2)
            self.saxvsms[i].fit(instances[t[0]],labels[t[0]],test=test,index=i+1)
            self.weights += [accuracy_score(self.saxvsms[i].predict(instances[t[1]]),labels[t[1]]) ** 2]
            fm.cursor_print(' weight ' + fm.float_form % self.weights[i], x=30, y=i+2)
            
        self.weights = hp.softmax(np.asarray(self.weights),alpha=10)
        print (self.weights)
        
        # # boosting
        # w_inst = np.zeros(shape=(len(instances)))+1.0/(1.0*len(instances))
        # self.weights = np.zeros(shape=(self.num_sax+1))
        # self.weights[0] = 1.0
        # for i in range(self.num_sax):
        #     print 'training ' + str(i),
        #     self.saxvsms[i].fit(instances,labels,w_inst)
        #     similarity_matrix = np.tensordot(self.weights[:i+1],\
        #             np.array([self.saxvsms[j].similarity_matrix(instances) for j in range(i+1)])\
        #             ,axes=([0],[0]))
        #     tmp_predict = np.argmax(similarity_matrix,axis=1)
        #     self.weights[i+1] = accuracy_score(fm.binarize(tmp_predict,classes=range(self.num_class)),labels,sample_weight=w_inst)
        #     w_inst *= 2.0 ** ( - (np.argmax(similarity_matrix,axis=1)==np.argmax(labels)))
        #     w_inst /= np.sum(w_inst**2)
        #     # print w_inst
        #     print ' accuray ',
        #     print self.weights[i+1]

    def predict(self,instances,truth=None):
        
        print ('predicting...')
        
        # probabilistic
        proba = np.zeros(shape=(len(instances),self.num_class))
        for i,s in enumerate(self.saxvsms):
            proba += s.predict_proba(instances) * self.weights[i]
        return hp.binarize(np.argmax(proba,axis=1),classes=range(self.num_class))
    
    
        '''
        # voting
        predictions = np.array([np.argmax(s.similarity_matrix(instances),axis=1) for s in self.saxvsms])
        return hp.binarize(np.array([np.argmax(np.bincount(predictions[:,i].reshape((len(self.saxvsms))),\
                                                           weights=self.weights,minlength=self.num_class)) \
                                     for i in range(len(instances))])\
                           , classes=range(self.num_class))
        '''
