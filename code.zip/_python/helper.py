import numpy as np
import formats as fm

from sklearn.preprocessing import label_binarize


def softmax(vector,alpha=1.0,axis=0):
    v   = vector - np.amax(vector,axis=axis,keepdims=True)
    eav = np.exp(alpha * v)
    return eav / np.sum(eav,axis=axis,keepdims=True)

def binarize(vect,classes):
    if len(classes)>2 :
        return label_binarize(vect,classes=classes)
    return np.array([[vect[i]==classes[0],vect[i]==classes[1]] for i in range(len(vect))],dtype=int)

def normalize(vector,axis=-1):
    norm = np.sum(vector ** 2.0, axis=axis,keepdims=True)
    return vector / ((norm + 1.0 * (norm <= 0.0))  ** 0.5)

def sigmoid(vector):
    return np.exp( -np.logaddexp(0,-vector) )
