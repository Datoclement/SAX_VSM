import numpy as np
import multiprocessing as mp

import formats as fm

from sklearn.model_selection import StratifiedShuffleSplit

def gradient_descent(weights,gradient,instances,labels,score,conf,test=None,index=None):
    
    batch_size        = conf['batch_size']
    lr                = conf['lr']
    lr_min            = conf['lr_min']
    n_iter            = conf['n_iter']
    annealing         = conf['annealing']
    annealing_power   = conf['annealing_power']
    bold_driver       = conf['bold_driver']
    bold_driver_incr  = conf['bold_driver_incr']
    bold_driver_decr  = conf['bold_driver_decr']        
    bold_driver_anne  = conf['bold_driver_anne']
    momentum          = conf['momentum']
    global_patience   = conf['global_patience']
    local_patience    = conf['local_patience']
    cv_size           = conf['cv_size']
    regularization    = conf['regularization']
    verbose           = conf['verbose']
    save              = conf['save']
    
    index             = int(mp.current_process().name) if index is None else index
    
    split_id = StratifiedShuffleSplit(n_splits=n_iter,\
                                    test_size=cv_size,\
                                    random_state=1).split(X=instances,y=labels)

    i          = 0
    no_better  = 0
    no_improve = 0
    best_score = 0.0
    last_score = 0.0
    deltw = np.zeros(shape=weights.shape)

    news = 'regularization: ' + fm.float_form % regularization
    fm.cursor_print(news)
    points = []
    while True:

        # condition of termination 
        if i >= n_iter or (no_better >= global_patience and no_improve >= local_patience) or lr <= lr_min:
            break

        train_id,test_id = next(split_id)
        num_train_inst   = len(train_id)

        train_X         = instances[train_id]
        train_y         = labels[train_id]
        test_X          = instances[test_id]
        test_y          = labels[test_id]

        # mini_batch gradient descent
        shuffled_id = np.random.permutation(num_train_inst)
        for j in range((num_train_inst - 1) // batch_size + 1):
            sample_id     = train_id[shuffled_id[j*batch_size:min((j+1)*batch_size,num_train_inst)]]
            grad          = gradient(sample_id)
            deltw         = momentum * deltw - lr * grad
            weights      += deltw

        # locating current situations
        
        train_score = score(train_X,train_y)
        test_score  = score(test_X,test_y)
        real_score  = score(test['X'],test['y'])          if       test is not None else None
        scores      = [train_score,test_score,real_score] if real_score is not None else [train_score,test_score]
        
        # learning rate adaptation
        if bold_driver:
            if test_score >= last_score:
                lr *= bold_driver_incr
            else:
                d_sc = last_score - test_score
                if d_sc > 0.01:
                    lr *= bold_driver_decr
            if bold_driver_anne:
                bold_driver_incr = (bold_driver_incr - 1.0) * n_iter / (0.0 + n_iter + i) + 1.0
        if annealing:
            lr *= n_iter / (0.0 + n_iter + i * annealing_power)

        # progression of variants
        i += 1
        if test_score <= last_score:
            no_improve += 1
        else:
            no_improve = 0
        last_score = test_score
        if test_score <= best_score:
            no_better += 1
        else:
            no_better = 0
            best_score = test_score

        if verbose:
            # to bring out
            news = ' step '      + fm.int_form   % i           \
                 + ' tr_score '  + fm.float_form % train_score \
                 + ' te_score '  + fm.float_form % test_score  \
                 + ' no_better ' + fm.int_form   % no_better   \
                 + ' no_improve' + fm.int_form   % no_improve  \
                 + ' lr '        + fm.float_form % lr 
            fm.cursor_print(news,y=index,x=25)
            
        points += [scores]

    if verbose:
        if test is not None:
            news = 'l = ' + fm.float_form % regularization + ' test_score ' + fm.float_form % score(test['X'],test['y'])
            fm.cursor_print(news,y=index+20)

    if save:
        err_t_curve_file = open('../output/err_t_curve_last_'+str(int(1E5 * regularization))+'.txt','w')
        curve = ''
        for tr,cv,te in points:
            curve += fm.float_form % tr + ',' + fm.float_form % cv + ',' + fm.float_form % te + '\n'
        err_t_curve_file.write(curve)
        err_t_curve_file.close()
    
    return weights