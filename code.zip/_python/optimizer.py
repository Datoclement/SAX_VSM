import sys,os
import numpy as np

import saxvsm as sv
import multiprocessing as mp
import formats as fm
import heapq

from sklearn.model_selection import cross_val_score,RandomizedSearchCV,GridSearchCV
from sklearn.metrics import accuracy_score

header = mp.Manager().list()
header.append("dataset\tconfiguration\tparams\ttest_score\n")

offset = 33

def scorer():
    memoize = dict()
    memoize['cnt'] = 0
    memoize['opts'] = []
    def score(params,data) :
        params = list(map(int,params))
        params_hash = np.asarray(params).tostring()
        if params_hash in memoize:
            return memoize[params_hash],0

        memoize['cnt'] += 1

        shape = data['shape']
        config = data['config']
        X = data['X']
        y = data['y']
        k = config['k_fold']
        nj = config['n_jobs']

        sv.saxvsm.init(params,shape,config)
        res = np.mean(cross_val_score(sv.saxvsm(),X,y, \
                # scoring="average_precision",\
                scoring="accuracy",\
                # scoring='f1',\
                cv=k,n_jobs=nj))

        memoize[params_hash]=-res

        limit = config['dr_maxsolv']
        if len(memoize['opts']) < limit:
            heapq.heappush(memoize['opts'],(res,params))
        elif res > memoize['opts'][0][0]:
            heapq.heappush(memoize['opts'],(res,params))
            heapq.heappop(memoize['opts'])

        curbest = heapq.nlargest(1,memoize['opts'])[0]
        news = "iteration " + fm.int_form % memoize['cnt'] \
            + " searching at " + fm.param_form % tuple(params) \
            + " score " + fm.float_form % res \
            + " best " + fm.float_form % curbest[0]
            #+ "/ " + fm.param_form % tuple(curbest[1])
        global offset
        fm.cursor_print(news,x=offset)

        return -res,0

    return score,memoize

def random_optimize(low,upp,data):

    score,memoize = scorer()

    def _scorer(estimator,X,y):
        return -score([estimator.len_window,estimator.len_word,estimator.num_alphabet],data)[0]

    params  = {\
        'len_window':np.arange(upp[0],dtype=int)+low[0],\
        'len_word':np.arange(upp[1],dtype=int)+low[1],\
        'num_alphabet':np.arange(upp[2],dtype=int)+low[2]}
    config  = data['config']
    shape   = data['shape']

    sv.saxvsm.init([0,0,0],data['shape'],data['config'])

    rd_iter = config['rd_iter']
    rscv    = RandomizedSearchCV(sv.saxvsm(),params,n_iter=rd_iter,cv=config['k_fold'],n_jobs=1,scoring=_scorer,random_state=0)

    rscv.fit(data['X'],data['y'])
    # gscv    = GridSearchCV(sv.saxvsm(),params,cv=1,scorer=_scorer)
    # gscv.fit(data['X'],data['y'])
    return score,memoize,rscv.best_score_

def greedy_optimize(score,memoize,data):

    pq = []
    opts = []
    inqueue = dict()

    for ps in [opt[1] for opt in memoize['opts']]:
        heapq.heappush(pq,(score(ps,data)[0],ps))
        inqueue[tuple(ps)] = True

    config = data['config']
    limit = config['gd_maxsolv']
    width = config['gd_width']

    curw = 0

    while True:
        if curw >= width or len(pq) == 0:
            break
        cur = heapq.heappop(pq)[1]
        curscore,_ = score(cur,data)
        curscore = -curscore
        if len(opts) < limit:
            heapq.heappush(opts,(curscore,cur))
            curw = 0
        elif curscore > opts[0][0]:
            heapq.heappushpop(opts,(curscore,cur))[1]
            curw = 0
        else:
            curw += 1
        l,p,a = cur
        valid = False

        for i in [-1,0,1]:
            for j in [-1,0,1]:
                for k in [-1,0,1]:
                    if i==0 and j==0 and k==0:
                        continue
                    nei = [l+i,p+j,a+k]
                    if tuple(nei) in inqueue:
                        continue
                    inqueue[tuple(nei)] = True
                    if l+i < 1 or p+j < 1 or a+k < 1:
                        continue
                    neiscore,_ = score(nei,data)
                    neiscore = -neiscore
                    if len(opts) == 0 or neiscore >= opts[0][0]:
                        heapq.heappush(pq,(-neiscore,nei))
    best_score = heapq.nlargest(1,opts)[0][0]
    opts = [ opt[1] for opt in opts ]

    return opts,best_score

def genetic_optimize():
    pass

def test_saxvsm(params,data,test,return_model=None):
    config = data['config']
    sv.saxvsm.init(params,data['shape'],config)
    model = sv.saxvsm()
    model.fit(data['X'],data['y'],test=test)
    score = accuracy_score(model.predict(test['X']),test['y'])
    if return_model is not None:
        conf = config['conf']
        return_model[conf] = (score,model)
    return score,model


def choose(params_opts,data,test):
    global offset
    best_score = 0.0
    params_opt = None
    for params in params_opts:
        test_score = test_saxvsm(params,data,test)[0]
        if test_score > best_score:
            best_score = test_score
            params_opt = params
        news = "possible config: " + fm.param_form % tuple(params) \
                + " test score: " + fm.float_form % test_score
        fm.cursor_print(news,x=offset)
        if best_score == 1.0:
            break
    return params_opt,best_score


def optimize(dataset,config,outputfile='output',low=None,upp=None,save=True):

    global header,offset

    data,test,train_size,test_size,filename = dataset

    news =  filename
    fm.cursor_print(news)

    len_series = data['shape'][1]
    num_sample = len(data['X'])

    #               len_window,         len_word,               num_alphabet
    if not low:
        low = [         1,                  1,                      2]
    if not upp:
        # upp = [         len_series,     min(30,len_series),     max(min(20,num_sample/10),5)]
        upp = [         len_series,         30,                     20]

    # saxvsm params
    data['config'] = config

    params_opts = None

    if config['optimization'] == 'rd_gd':

        score,memoize,score_opt = random_optimize(low,upp,data)

        news = "random_opt: " + fm.float_form % score_opt
        fm.cursor_print(news,x=offset)

        params_opts,score_opt = greedy_optimize(score,memoize,data)

        news = "greedy_opt: " + fm.float_form % score_opt
        fm.cursor_print(news,x=offset)

        '''
        if config['optimization'] == 'dr_gd':

            score,memoize,score_opt = direct_optimize(low,upp,data)

            print ("direct_opt: ",end='')
            print (fm.float_form % score_opt)

            params_opts,score_opt = greedy_optimize(score,memoize,data)

            print ("greedy_opt: ",end='')
            print (fm.float_form % score_opt)
        '''

    elif config['optimization'] == 'gd':
        score,memoize = scorer()
        start = [1,1,1] if not config['gd_start'] else config['gd_start']
        score(start,data)
        params_opts,score_opt = greedy_optimize(score,memoize,data)


    params_opt,best_score = choose(params_opts,data,test)

    news = "params_opt: " + fm.param_form % tuple(params_opt) \
            + " best_score: " + fm.float_form % best_score \
            + " rate_of_error: " + fm.float_form % (1-best_score)

    fm.cursor_print(news,x=offset)
    sv.saxvsm.init(params_opt,data['shape'],data['config'])
    header += [filename + '\t' \
            + fm.conf_form % config['conf'] + '\t' \
            + fm.param_form % tuple(params_opt) + '\t' \
            + fm.float_form % (1-best_score) + '\n']
    if save:
        infofile = open('../output/'+outputfile+'.txt','w')
        infofile.write(''.join(header))
        infofile.close()

    return params_opt
