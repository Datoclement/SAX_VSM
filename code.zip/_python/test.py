import saxvsm as sv
import optimizer as opt
import parser as ps
import formats as fm
import ensemble as esb
import helper as hp

import numpy as np
import scipy.signal as sg
import os
import multiprocessing as mp
import subprocess as sbp
import itertools as it
import zipfile as zf

from sklearn.metrics import accuracy_score
from sklearn.ensemble import BaggingClassifier

import matplotlib.pyplot as plt

# single test
def single_test(single_database,folder,single_params,config,interpretation=False,index=-1,max_pic=10):

    def clear_png():
        path = '../output/'
        filelist = [ f for f in os.listdir(path) if f.endswith(".png") ]
        for f in filelist:
            os.remove(path+f)

    single_data,single_test,single_train_size,single_test_size,single_database = ps.parse(single_database,folder)

    num_per_class = np.bincount(np.argmax(single_data['y'],axis=-1)) + np.bincount(np.argmax(single_test['y'],axis=-1))
    random_guess_accuracy = np.amax(num_per_class) / (1.0 * np.sum(num_per_class))
    fm.cursor_print(str(random_guess_accuracy),y=3)
    single_data['config']=config

    configs_possibles = list(it.product(*([['narctan']]+[[False]]+[[True]]+[[True]])))
    # configs_possibles = list(it.product(*([['ntfidf','tfidf','arctan','narctan']]+[[True,False]] * 3)))

    # print 'Single test on ' + single_database
    # print 'params: ',
    # print fm.param_form % tuple(single_params)

    models = mp.Manager().dict()
    print (single_database)
    ts = []
    ls = np.logspace(-5,1,13)
    for i,conf in enumerate(configs_possibles):
        config['conf'] = conf
        # for j,l in enumerate(ls):
        #     config['sgd_params']['regularization'] = l
        #     ts += [mp.Process(target=opt.test_saxvsm,\
        #                       args=(single_params,single_data,single_test,models),\
        #                       name=str(i*len(ls) + j + 1))]
        #     ts[-1].start()
        #
        # config['sgd'] = False
        ts += [mp.Process(target=opt.test_saxvsm,\
                              args=(single_params,single_data,single_test,models),\
                              name=str(i*len(ls) + len(ls) + 1))]
        ts[-1].start()

    for t in ts:
        t.join()
    for i,conf in enumerate(configs_possibles):
        news = fm.conf_form % conf + ' ' + fm.float_form % models[conf][0]
        fm.cursor_print(news,y=i+1+len(ls))
    # interpretation of failure
    if interpretation:

        if index >= 0:
            for conf in configs_possibles:
                models[conf][1].interpret(single_test['X'][index], \
                        title='test_' + str(index)+'_'+str(conf)+'.png', \
                        truth=np.argmax(single_test['y'][index]))

        else:
            clear_png()

            for conf in configs_possibles:
                model = models[conf][1]
                predictions = model.predict(single_test['X'])
                print(predictions)
                for i in np.random.permutation(single_test_size)[:min(single_test_size,max_pic)]:
                    # if (predictions[i] != single_test['y'][i]).any():
                    #     model.interpret(single_test['X'][i], \
                    #             title='test_' + str(i)+'_'+str(conf)+'.png', \
                    #             truth=np.argmax(single_test['y'][i]))
                    model.interpret(single_test['X'][i], \
                            title='test_' + str(i)+'_'+str(conf)+'.png', \
                            truth=np.argmax(single_test['y'][i]))

output_dir = '../output/'
data_dir   = '../data/'

np.random.seed(0)

num_cpu    = mp.cpu_count()

#            (weighting,    reduction,  mean,      trend)
conf       = ( 'ntfidf',        True,   False,       False)

#            (n_estimators, test_size,  softmax_power, num_filter)
esb_conf   = (          20,       0.3,            5.0,          3)

config     = {\
            'k_fold':3,\
            'n_jobs':-1,\
            'dr_precision':0.001,\
            'dr_version':1,\
            'dr_maxit':6000,\
            'dr_maxsolv':20,\
            'gd_maxsolv':30,\
            'gd_width':10,\
            'gd_start':[73,24,6],\
            'rd_iter':200,\
            'conf':conf,\
            'inter_var':'mixed',\
            'sgd':False,\
            'sgd_params':{'batch_size':7,\
                          'n_iter':1000,\
                          'lr':1E-3,\
                          'lr_min':1E-16,\
                          'regularization':1E-2,\
                          'global_patience':500,\
                          'local_patience':150,\
                          'annealing':True,\
                          'annealing_power':3E-1,\
                          'bold_driver':True,\
                          'bold_driver_incr':1.2,\
                          'bold_driver_decr':5E-1,\
                          'bold_driver_anne':False,\
                          'momentum':0.3,\
                          'cv_size':0.3,\
                          'verbose':True,\
                          'save':True},\
            'optimization':'rd_gd',\
            'esb_conf':esb_conf}

# single test
sbp.call(['clear'])

single_test( \
        'PenDigits',\
        'mts_dataset',\
        [4,4,3],\
        config=config,interpretation=True,max_pic=50)

# MALLAT        uts tan   tttt 293 5 12
# CMUsubject16  mts tfidf tftt 21  7 2
# ECG           mts tan   ffff 29  8 6
# PenDigits	( narctan, False,  True,  True )	[   4,  4,  3]	mixed	1.60e-01
'''
l = [f for f in os.listdir(output_dir) if f[:3] == 'err']
with zf.ZipFile(output_dir+'curves.zip','w') as res:
    for f in l:
        res.write(output_dir+f)
'''

# # optimization of parameters


'''
sbp.run('clear')

folder   = 'mts_dataset'
datasets = [ f for f in os.listdir('../data/'+folder+'/') ]
outputfile = 'info3'
ts = []
weightings = ['warctan']
for i,filename in enumerate(datasets):
    dataset = ps.parse(filename,folder)
    # opt.optimize(dataset,config,outputfile)
    for j,w in enumerate(weightings):
        config['weighting'] = w
        ts += [mp.Process(target=opt.optimize,args=(dataset,config,outputfile),name=str((len(weightings))*i+j+1))]
        ts[-1].start()
    break


for t in ts:
    t.join()
'''

'''
sbp.run('clear')
filename = 'LP2'
folder   = 'mts_dataset'
dataset = ps.parse(filename,folder)
data,test,_,_,_ = dataset
clf = esb.ensemble(dataset,config)
clf.fit(data['X'],data['y'],test)
print (accuracy_score(clf.predict(test['X']),test['y']))
'''

def get_time_series_image(ys,filename,labels=None):
    fig = plt.figure()
    if isinstance(ys,list):
        if labels is None:
            labels = map(str,range(len(ys)))
        x   = np.arange(len(ys[0]))
        for i,y in enumerate(ys):
            plt.plot(x,y,label=labels[i])
        plt.legend()
    else:
        x   = np.arange(len(ys))
        plt.plot(x,ys)
    fig.savefig('../output/playground/' + filename + '.png')

def clear_png():
    path = '../output/playground/'
    filelist = [ f for f in os.listdir(path) if f.endswith(".png") ]
    for f in filelist:
        os.remove(path+f)
