import numpy as np

class sparse_matrix:
    
    def __init__(self,row=0,col=0):
        self.row = row
        self.col = col
        self.mat = []
        
    def add_col(self,new_col):
        self.col += 1
        effective_indices = new_col > 0
        sparse_new_col = [list(map(tuple,np.array( \
                                                  (np.arange(len(new_col),dtype=int)[effective_indices],\
                                                   new_col[effective_indices])).T))]
        self.row = max(self.row,sparse_new_col[0][-1][0]+1)
        self.mat += sparse_new_col
        
    def to_matrix(self):
        result = np.zeros(shape=(self.row,self.col),dtype=type(self.mat[0][0][1]))
        for c,col in enumerate(self.mat):
            for r,val in col:
                result[r,c] = val
        return result