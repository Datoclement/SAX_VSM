import os
import numpy as np
import multiprocessing as mp


int_form = '%4d'
float_form = '%.2e'
param_form = '[%4d,%3d,%3d]'
time_form = 't1:%.3f\tt2:%.3f\tt3:%.3f'
conf_form = '( %7s, %5s, %5s, %5s )'

def param_to_string(param):
    if not isinstance(param,list):
        return int_form % param
    string = '['
    for p in param:
        string += param_to_string(p) + ','
    string = string[:-1] + ']'
    return string

def screen_line():
    try:
        return int(mp.current_process().name)
    except(ValueError):
        return 1

def cursor_print(s,x=0,y=None,l=None):
    
    h,w = os.popen('stty size', 'r').read().split()
    h   = int(h) - 1
    w   = int(w) + 7
    
    assert y != 0
    y = screen_line() if y is None else y
    if y <= 0:
        y += 1
    y = ((y - 1) % h + h) % h + 1
    
    l = w             if l is None else l
    
    strings  = ('\033['+str(y)+';'+str(x)+'H'+s).split('\n')
    for i in range(len(strings)):
        strings[i] += ' ' * (l-x-len(strings[i])) + '\n'
    print (''.join(strings))
